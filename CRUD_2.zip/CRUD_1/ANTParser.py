# Generated from ANT.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,19,81,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,1,0,4,0,24,8,0,11,0,12,0,25,
        1,0,1,0,1,1,1,1,1,1,1,1,3,1,34,8,1,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,
        3,1,3,1,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,6,1,
        6,1,6,1,6,5,6,62,8,6,10,6,12,6,65,9,6,1,6,1,6,1,7,1,7,1,7,1,7,1,
        8,1,8,1,8,1,8,1,9,1,9,1,10,1,10,1,10,0,0,11,0,2,4,6,8,10,12,14,16,
        18,20,0,2,1,0,12,15,1,0,17,18,74,0,23,1,0,0,0,2,33,1,0,0,0,4,35,
        1,0,0,0,6,40,1,0,0,0,8,45,1,0,0,0,10,52,1,0,0,0,12,57,1,0,0,0,14,
        68,1,0,0,0,16,72,1,0,0,0,18,76,1,0,0,0,20,78,1,0,0,0,22,24,3,2,1,
        0,23,22,1,0,0,0,24,25,1,0,0,0,25,23,1,0,0,0,25,26,1,0,0,0,26,27,
        1,0,0,0,27,28,5,0,0,1,28,1,1,0,0,0,29,34,3,4,2,0,30,34,3,6,3,0,31,
        34,3,8,4,0,32,34,3,10,5,0,33,29,1,0,0,0,33,30,1,0,0,0,33,31,1,0,
        0,0,33,32,1,0,0,0,34,3,1,0,0,0,35,36,5,1,0,0,36,37,5,16,0,0,37,38,
        5,2,0,0,38,39,3,12,6,0,39,5,1,0,0,0,40,41,5,3,0,0,41,42,5,16,0,0,
        42,43,5,4,0,0,43,44,3,16,8,0,44,7,1,0,0,0,45,46,5,5,0,0,46,47,5,
        16,0,0,47,48,5,6,0,0,48,49,3,12,6,0,49,50,5,4,0,0,50,51,3,16,8,0,
        51,9,1,0,0,0,52,53,5,7,0,0,53,54,5,16,0,0,54,55,5,4,0,0,55,56,3,
        16,8,0,56,11,1,0,0,0,57,58,5,8,0,0,58,63,3,14,7,0,59,60,5,9,0,0,
        60,62,3,14,7,0,61,59,1,0,0,0,62,65,1,0,0,0,63,61,1,0,0,0,63,64,1,
        0,0,0,64,66,1,0,0,0,65,63,1,0,0,0,66,67,5,10,0,0,67,13,1,0,0,0,68,
        69,5,16,0,0,69,70,5,11,0,0,70,71,3,20,10,0,71,15,1,0,0,0,72,73,5,
        16,0,0,73,74,3,18,9,0,74,75,3,20,10,0,75,17,1,0,0,0,76,77,7,0,0,
        0,77,19,1,0,0,0,78,79,7,1,0,0,79,21,1,0,0,0,3,25,33,63
    ]

class ANTParser ( Parser ):

    grammarFileName = "ANT.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'PUSH'", "'WITH'", "'PULL'", "'FILTER'", 
                     "'SHIFT'", "'REPLACE'", "'DROP'", "'['", "','", "']'", 
                     "'=>'", "'=='", "'!='", "'>'", "'<'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "ID", "NUMBER", "STRING", "WS" ]

    RULE_start = 0
    RULE_stmt = 1
    RULE_pushStmt = 2
    RULE_pullStmt = 3
    RULE_shiftStmt = 4
    RULE_dropStmt = 5
    RULE_struct = 6
    RULE_pair = 7
    RULE_cond = 8
    RULE_operator = 9
    RULE_value = 10

    ruleNames =  [ "start", "stmt", "pushStmt", "pullStmt", "shiftStmt", 
                   "dropStmt", "struct", "pair", "cond", "operator", "value" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    ID=16
    NUMBER=17
    STRING=18
    WS=19

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(ANTParser.EOF, 0)

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTParser.StmtContext)
            else:
                return self.getTypedRuleContext(ANTParser.StmtContext,i)


        def getRuleIndex(self):
            return ANTParser.RULE_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart" ):
                listener.enterStart(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart" ):
                listener.exitStart(self)




    def start(self):

        localctx = ANTParser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 23 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 22
                self.stmt()
                self.state = 25 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 170) != 0)):
                    break

            self.state = 27
            self.match(ANTParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def pushStmt(self):
            return self.getTypedRuleContext(ANTParser.PushStmtContext,0)


        def pullStmt(self):
            return self.getTypedRuleContext(ANTParser.PullStmtContext,0)


        def shiftStmt(self):
            return self.getTypedRuleContext(ANTParser.ShiftStmtContext,0)


        def dropStmt(self):
            return self.getTypedRuleContext(ANTParser.DropStmtContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt" ):
                listener.enterStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt" ):
                listener.exitStmt(self)




    def stmt(self):

        localctx = ANTParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stmt)
        try:
            self.state = 33
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)
                self.state = 29
                self.pushStmt()
                pass
            elif token in [3]:
                self.enterOuterAlt(localctx, 2)
                self.state = 30
                self.pullStmt()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 3)
                self.state = 31
                self.shiftStmt()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 4)
                self.state = 32
                self.dropStmt()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PushStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ANTParser.ID, 0)

        def struct(self):
            return self.getTypedRuleContext(ANTParser.StructContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_pushStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPushStmt" ):
                listener.enterPushStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPushStmt" ):
                listener.exitPushStmt(self)




    def pushStmt(self):

        localctx = ANTParser.PushStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_pushStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35
            self.match(ANTParser.T__0)
            self.state = 36
            self.match(ANTParser.ID)
            self.state = 37
            self.match(ANTParser.T__1)
            self.state = 38
            self.struct()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PullStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ANTParser.ID, 0)

        def cond(self):
            return self.getTypedRuleContext(ANTParser.CondContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_pullStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPullStmt" ):
                listener.enterPullStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPullStmt" ):
                listener.exitPullStmt(self)




    def pullStmt(self):

        localctx = ANTParser.PullStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_pullStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 40
            self.match(ANTParser.T__2)
            self.state = 41
            self.match(ANTParser.ID)
            self.state = 42
            self.match(ANTParser.T__3)
            self.state = 43
            self.cond()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ShiftStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ANTParser.ID, 0)

        def struct(self):
            return self.getTypedRuleContext(ANTParser.StructContext,0)


        def cond(self):
            return self.getTypedRuleContext(ANTParser.CondContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_shiftStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterShiftStmt" ):
                listener.enterShiftStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitShiftStmt" ):
                listener.exitShiftStmt(self)




    def shiftStmt(self):

        localctx = ANTParser.ShiftStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_shiftStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 45
            self.match(ANTParser.T__4)
            self.state = 46
            self.match(ANTParser.ID)
            self.state = 47
            self.match(ANTParser.T__5)
            self.state = 48
            self.struct()
            self.state = 49
            self.match(ANTParser.T__3)
            self.state = 50
            self.cond()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DropStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ANTParser.ID, 0)

        def cond(self):
            return self.getTypedRuleContext(ANTParser.CondContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_dropStmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDropStmt" ):
                listener.enterDropStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDropStmt" ):
                listener.exitDropStmt(self)




    def dropStmt(self):

        localctx = ANTParser.DropStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_dropStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 52
            self.match(ANTParser.T__6)
            self.state = 53
            self.match(ANTParser.ID)
            self.state = 54
            self.match(ANTParser.T__3)
            self.state = 55
            self.cond()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StructContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def pair(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(ANTParser.PairContext)
            else:
                return self.getTypedRuleContext(ANTParser.PairContext,i)


        def getRuleIndex(self):
            return ANTParser.RULE_struct

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStruct" ):
                listener.enterStruct(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStruct" ):
                listener.exitStruct(self)




    def struct(self):

        localctx = ANTParser.StructContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_struct)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self.match(ANTParser.T__7)
            self.state = 58
            self.pair()
            self.state = 63
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==9:
                self.state = 59
                self.match(ANTParser.T__8)
                self.state = 60
                self.pair()
                self.state = 65
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 66
            self.match(ANTParser.T__9)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PairContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ANTParser.ID, 0)

        def value(self):
            return self.getTypedRuleContext(ANTParser.ValueContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_pair

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPair" ):
                listener.enterPair(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPair" ):
                listener.exitPair(self)




    def pair(self):

        localctx = ANTParser.PairContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_pair)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 68
            self.match(ANTParser.ID)
            self.state = 69
            self.match(ANTParser.T__10)
            self.state = 70
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CondContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(ANTParser.ID, 0)

        def operator(self):
            return self.getTypedRuleContext(ANTParser.OperatorContext,0)


        def value(self):
            return self.getTypedRuleContext(ANTParser.ValueContext,0)


        def getRuleIndex(self):
            return ANTParser.RULE_cond

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCond" ):
                listener.enterCond(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCond" ):
                listener.exitCond(self)




    def cond(self):

        localctx = ANTParser.CondContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_cond)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            self.match(ANTParser.ID)
            self.state = 73
            self.operator()
            self.state = 74
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return ANTParser.RULE_operator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOperator" ):
                listener.enterOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOperator" ):
                listener.exitOperator(self)




    def operator(self):

        localctx = ANTParser.OperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_operator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 76
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 61440) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(ANTParser.STRING, 0)

        def NUMBER(self):
            return self.getToken(ANTParser.NUMBER, 0)

        def getRuleIndex(self):
            return ANTParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)




    def value(self):

        localctx = ANTParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 78
            _la = self._input.LA(1)
            if not(_la==17 or _la==18):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





