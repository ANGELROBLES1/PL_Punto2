# Generated from ANT.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .ANTParser import ANTParser
else:
    from ANTParser import ANTParser

# This class defines a complete listener for a parse tree produced by ANTParser.
class ANTListener(ParseTreeListener):

    # Enter a parse tree produced by ANTParser#start.
    def enterStart(self, ctx:ANTParser.StartContext):
        pass

    # Exit a parse tree produced by ANTParser#start.
    def exitStart(self, ctx:ANTParser.StartContext):
        pass


    # Enter a parse tree produced by ANTParser#stmt.
    def enterStmt(self, ctx:ANTParser.StmtContext):
        pass

    # Exit a parse tree produced by ANTParser#stmt.
    def exitStmt(self, ctx:ANTParser.StmtContext):
        pass


    # Enter a parse tree produced by ANTParser#pushStmt.
    def enterPushStmt(self, ctx:ANTParser.PushStmtContext):
        pass

    # Exit a parse tree produced by ANTParser#pushStmt.
    def exitPushStmt(self, ctx:ANTParser.PushStmtContext):
        pass


    # Enter a parse tree produced by ANTParser#pullStmt.
    def enterPullStmt(self, ctx:ANTParser.PullStmtContext):
        pass

    # Exit a parse tree produced by ANTParser#pullStmt.
    def exitPullStmt(self, ctx:ANTParser.PullStmtContext):
        pass


    # Enter a parse tree produced by ANTParser#shiftStmt.
    def enterShiftStmt(self, ctx:ANTParser.ShiftStmtContext):
        pass

    # Exit a parse tree produced by ANTParser#shiftStmt.
    def exitShiftStmt(self, ctx:ANTParser.ShiftStmtContext):
        pass


    # Enter a parse tree produced by ANTParser#dropStmt.
    def enterDropStmt(self, ctx:ANTParser.DropStmtContext):
        pass

    # Exit a parse tree produced by ANTParser#dropStmt.
    def exitDropStmt(self, ctx:ANTParser.DropStmtContext):
        pass


    # Enter a parse tree produced by ANTParser#struct.
    def enterStruct(self, ctx:ANTParser.StructContext):
        pass

    # Exit a parse tree produced by ANTParser#struct.
    def exitStruct(self, ctx:ANTParser.StructContext):
        pass


    # Enter a parse tree produced by ANTParser#pair.
    def enterPair(self, ctx:ANTParser.PairContext):
        pass

    # Exit a parse tree produced by ANTParser#pair.
    def exitPair(self, ctx:ANTParser.PairContext):
        pass


    # Enter a parse tree produced by ANTParser#cond.
    def enterCond(self, ctx:ANTParser.CondContext):
        pass

    # Exit a parse tree produced by ANTParser#cond.
    def exitCond(self, ctx:ANTParser.CondContext):
        pass


    # Enter a parse tree produced by ANTParser#operator.
    def enterOperator(self, ctx:ANTParser.OperatorContext):
        pass

    # Exit a parse tree produced by ANTParser#operator.
    def exitOperator(self, ctx:ANTParser.OperatorContext):
        pass


    # Enter a parse tree produced by ANTParser#value.
    def enterValue(self, ctx:ANTParser.ValueContext):
        pass

    # Exit a parse tree produced by ANTParser#value.
    def exitValue(self, ctx:ANTParser.ValueContext):
        pass



del ANTParser