from antlr4 import *
from ANTLexer import ANTLexer
from ANTParser import ANTParser
from antlr4.error.ErrorListener import ErrorListener


class ErrorPersonalizado(ErrorListener):
    def syntaxError(self, recognizer, offendingSymbol, line, column, msg, e):
        print(f"Linea {line}, Columna {column} -> ERROR: {msg}")


def evaluar_linea(linea, num):
    input_stream = InputStream(linea)
    lexer = ANTLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ANTParser(stream)

    # Quitar errores por defecto
    parser.removeErrorListeners()
    parser.addErrorListener(ErrorPersonalizado())

    print(f"Analizando linea {num}: {linea}")

    parser.start()


def evaluar_archivo(nombre_archivo):
    with open(nombre_archivo, 'r') as f:
        lineas = f.readlines()

    for i, linea in enumerate(lineas, start=1):
        if linea.strip():
            evaluar_linea(linea.strip(), i)


if __name__ == "__main__":
    evaluar_archivo("ejemplos.txt")
